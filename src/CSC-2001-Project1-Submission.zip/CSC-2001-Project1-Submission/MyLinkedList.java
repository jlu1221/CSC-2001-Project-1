public class MyLinkedList {

    // Node class (head is the beginning of the list)
    private Node head;

    private class Node {
        Session session;
        Node next;
    }

    // Constructor (start with a empty list)
    public MyLinkedList() {
        head = null;
    }

    // addFirst method
    // Purpose: add a session to the beginning of the linkedlist
    // Example: session1 --> [session1]

    public void addFirst(Session session) {
        Node newNode = new Node();
        newNode.session = session;
        newNode.next = head;
        head = newNode;
    }
    // addLast method
    // Purpose: add a session to the end of the list, always checking if the next node is null
    // Example: session 2 and 4 --> [session1, session2, session4] {added 2 and 4}

    public void addLast(Session session) {
        Node newNode = new Node();
        newNode.session = session;
        newNode.next = null;

        // if list is empty
        if (head == null) {
            head = newNode;
            return;
        }

        // start at the current node
        Node current = head;

        // Move down the list
        while (current.next != null) {
            current = current.next;
        }

        current.next = newNode;
    }
    // insertAfter method
    // Purpose: this method adds an item to the existing session list and updates the list with the new sessions. Best use with sessionID
    // Example: session3 --> [session1, session2, session3, session4] {inserted session3}

    public void insertAfter(Session session) {
        Node newNode = new Node();
        newNode.session = session;

        Node current = head;

        if (head == null) {
            head = newNode;
            return;
        }

        newNode.next = current.next;
        current.next = newNode;
    }
    // searchByID method
    // Purpose: this method search for the ID given by the user and return the string ID
    // Example: ID:101 --> sessionID: 101

    public String searchByID(int id) {
        Node current = head;

        while (current != null) {
            if (current.session.getSessionID() == id ) {
                return current.session.toString();
            }

            current = current.next;
        }
        return "Session not found";
    }
    // search ByMentor method
    // Purpose: this method search for the given mentor given by the user and return the string of the mentor's name
    // Example: Mentor name: Jordan --> Session Mentor: Jordan

    public String searchByMentor(String name) {
        Node current = head;

        while (current != null) {
            if (current.session.getMentor().equals(name)) {
                return current.session.toString();
            }

            current = current.next;
        }

        return "No session found for mentor " + name;
    }
    // remove method
    // Purpose: this method will remove one of the session and return a string
    // Example: session3 --> [session1, session2, session4] {session 3 was removed}

    public String remove(Session session) {
        // If the list is empty
        if (head == null) {
            return "Session not found";
        }

        // If the session to remove is the first node
        if (head.session.getSessionID() == session.getSessionID()) {
            head = head.next;
            return "Session has been removed";
        }

        Node current = head;

        // Search for the next node before removing
        while (current.next != null) {

            if (current.next.session.getSessionID() == session.getSessionID()) {
                current.next = current.next.next;
                return "Session has been removed";
            }

            current = current.next;
        }

        return "Session not found";
    }
    // registerParticipant method
    // Purpose: this method check if the current number of participants is less than the max amount, then add that participant (add 1)
    // Example: session102 max capacity = 15; current = 5; 5 < 15 (TRUE); can register a participant; current = 5 + 1 {6}

    public boolean registerParticipant(Session session) {

        if (session.getCurrentParticipants() < session.getMaxParticipants()) {
            session.setCurrentParticipants(session.getCurrentParticipants() + 1);

            return true;
        }

        return false;
    }


    // display method
    // Purpose: display method prints at the list in output
    // Example: Display the print statement when running main

    public String display() {
        String result = "";
        Node current = head;

        while (current != null) {
            result += current.session + "\n";
            current = current.next;
        }

        return result;
    }

    public Session getSessionByID(int id) {
        Node current = head;

        while (current != null) {
            if (current.session.getSessionID() == id) {
                return current.session;
            }

            current = current.next;
        }

        return null;
    }
}
